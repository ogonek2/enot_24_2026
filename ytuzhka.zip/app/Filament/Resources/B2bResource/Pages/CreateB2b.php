<?php

namespace App\Filament\Resources\B2bResource\Pages;

use App\Filament\Resources\B2bResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateB2b extends CreateRecord
{
    protected static string $resource = B2bResource::class;
}
