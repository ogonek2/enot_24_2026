<?php

return [
    'bot_token' => env('TELEGRAM_BOT_TOKEN', '8360742949:AAG-cG88L2IF4HUbpdphYjhAPXKdeVZ1bzE'),
    'chat_id' => env('TELEGRAM_CHAT_ID', '-4777602155'),
    'enabled' => env('TELEGRAM_ENABLED', true),
];
