<div class="app-container-footer-bar">
    <div class="elements">
        <div class="element">
            <div class="logo-path">
                <a href="#">
                    <img src="{{ asset('storage/source/logo.svg') }}" alt="">
                    <span>
                        <p>
                            ytuzhka.ua
                        </p>
                    </span>
                </a>
            </div>
        </div>
        <div class="element">
            <ul>
                <li>
                    <b>
                        Навігація
                    </b>
                </li>
                <li>
                    <a href="#">Наші послуги</a>
                </li>
                <li>
                    <a href="#">Ціни</a>
                </li>
                <li>
                    <a href="#">Рекомендації по догляду</a>
                </li>
                <li>
                    <a href="#">Доставка</a>
                </li>
                <li>
                    <a href="#">Контакти</a>
                </li>
            </ul>
        </div>
        <div class="element">
            <ul>
                <li>
                    <b>Популярні послуги</b>
                </li>
                <li>
                    <a href="#">Прасування</a>
                </li>
                <li>
                    <a href="#">Аквачистка</a>
                </li>
                <li>
                    <a href="#">Чистка текстильних виробів </a>
                </li>
                <li>
                    <a href="#">Чистка хутра, шуб,
                        хутряних виробів</a>
                </li>
                <li>
                    <a href="#">Чистка одягу зі шкіри,
                        дублянок</a>
                </li>
                <li>
                    <a href="#">Чистка сумок</a>
                </li>
            </ul>
        </div>
        <div class="element">
            <ul>
                <li>
                    <b>
                        Графік роботи
                    </b>
                </li>
                <li>
                    <a href="#">
                        Приймаємо замовлення з 10:00-20:00 без вихідних.
                    </a>
                </li>
                <li>
                    <a href="#">Графік роботи кур'єрської
                        служби з 10:00-20:00 без вихідних.</a>
                </li>
            </ul>
        </div>
        <div class="element">
            <ul>
                <li>
                    <b>
                        Контакти
                    </b>
                </li>
                <li>
                    <a href="#">
                        <b>
                            <i class="fa-solid fa-phone"></i>
                            <span>+38 (xxx) xxx-xx-xx</span>
                        </b>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <b>
                            <i class="fa-solid fa-envelope"></i>
                            <span>email@gmail.com</span>
                        </b>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
