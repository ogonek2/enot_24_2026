@extends('admin.layouts.app')

@section('page')Вітаю!@endsection
@section('page_description')Перейдіть до розділу керування@endsection