<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Category;
use App\Models\Service;

class IndexServices extends Controller
{
    public function index() {
        $categories = Category::with('services')->get();

        return view('welcome', [
            'categories' => $categories,
        ]);
    }
}
