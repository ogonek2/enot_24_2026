<div class="app-container-elements-box box prices-box_block">
    <div class="backdrop-padding">
        <div class="header-title">
            <h1 class="header-b-title">
                Ціни
            </h1>
        </div>
        <div class="items-box">
            <div class="item">
                <div class="tags-category-elements">
                    <?php $__currentLoopData = $categories->filter(fn($category) => $category->services->isNotEmpty()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="element" data-item="item_<?php echo e($category->href); ?>">
                            <p>
                                <?php echo e($category->name); ?>

                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="item">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="element-list" data-item='item_<?php echo e($category->href); ?>'>
                        <ul>
                            <?php $__currentLoopData = $category->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <p><?php echo e($service->name); ?></p>
                                    <span><?php echo e($service->price); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\OpenServer\domains\localhost\ytuzhka\resources\views/includes/elements/price-box.blade.php ENDPATH**/ ?>