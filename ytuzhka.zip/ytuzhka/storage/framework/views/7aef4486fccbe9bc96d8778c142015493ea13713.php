<div class="app-container-elements-box box services-box_block">
    <div class="header-title">
        <h1 class="header-b-title">
            Наші послуги
        </h1>
    </div>
    <div class="items-box">
        <div class="item">
            <div class="slides-banner">
                <div class="slide banner">
                    <img src="<?php echo e(asset('storage/source/images/services/slide_img_01.png')); ?>"
                        alt="Екочистка одягу та домашнього текстилю">
                </div>
            </div>
        </div>
        <div class="item">
            <div class="column-services-elements">
                <div class="element">
                    <h1>
                        Домашній та<br>
                        готельний текстиль
                    </h1>
                    <ul>
                        <li>Чистка текстильного одягу</li>
                        <li>Аквачистка</li>
                        <li>Прасування</li>
                        <li>Чистка домашнього текстилю</li>
                        <li>Чистка ковдр, подушок</li>
                        <li>Чистка м’яких іграшок</li>
                    </ul>
                </div>
                <div class="element">
                    <h1>
                        Спецодяг, шкіра
                        та хутро
                    </h1>
                    <ul>
                        <li>Чистка одягу зі шкіри
                            та дублянок</li>
                        <li>Чистка хутра, шуб, та
                            хутряних виробів</li>
                    </ul>
                </div>
                <div class="element">
                    <h1>
                        М’які меблі
                        та<br>килими
                    </h1>
                    <ul>
                        <li>Чистка м’яких меблів</li>
                        <li>Прання килимів</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\OpenServer\domains\localhost\ytuzhka\resources\views/includes/elements/services-box.blade.php ENDPATH**/ ?>