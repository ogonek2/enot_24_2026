

<?php $__env->startSection('page'); ?>Вітаю!<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_description'); ?>Перейдіть до розділу керування<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\localhost\ytuzhka\resources\views/admin/admin_pages/dashboard.blade.php ENDPATH**/ ?>