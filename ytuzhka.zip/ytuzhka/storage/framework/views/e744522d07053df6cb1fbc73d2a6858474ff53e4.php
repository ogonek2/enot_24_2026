<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('storage/source/logo_icon.svg')); ?>" type="image/x-icon">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/box_containers.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/content.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/elements.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fixed_elements.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/windows.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/swiper-bundle.min.css')); ?>">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

    
    <?php echo $__env->yieldContent('styles'); ?>
    
    <?php echo $__env->yieldContent('seo_tags'); ?>
</head>

<body>
    
    <div id="app">
        <?php echo $__env->make('includes.windows.feedback_form-fd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="app-container">
            <div class="app-container-navigator">
                <?php echo $__env->make('includes.fixed.navigator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="app-container-elements">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <div class="app-container-footer">
                <?php echo $__env->make('includes.fixed.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.9/jquery.inputmask.min.js"
        integrity="sha512-F5Ul1uuyFlGnIT1dk2c4kB4DBdi5wnBJjVhL7gQlGh46Xn0VhvD8kgxLtjdZ5YN83gybk/aASUAlpdoWUjRR3g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.modal').hide()
        })
    </script>
    <script>
        $(document).on('click', '.modal_fade', function() {
            let this_data = $(this).data('modal');
            $(`#modalfade_${this_data}`).show()
        })
        $(document).on('click', '.close-modal-md', function() {
            let this_data = $(this).data('modal');
            $(`#modalfade_${this_data}`).hide()
        })
    </script>
    <script>
        $(document).on('click', '.burger-btn', function() {
            $(this).toggleClass('active')
            $('.fixed-container-burger-bar').toggleClass('fade')
        })
    </script>
</body>

</html>
<?php /**PATH D:\OpenServer\domains\localhost\ytuzhka\resources\views/layouts/app.blade.php ENDPATH**/ ?>